$: << File.join(File.dirname(__FILE__), '/../lib' )
require 'rspec'
require 'savanna-outliers'