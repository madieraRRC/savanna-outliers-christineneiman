module Savanna
  module Outliers
  	VERSION = '0.0.1'
  end
end